DEFAULT_TICKERS = ["IREN", "GOOG", "NVDA", "EL", "UNH", "CRDO", "TSLQ", "TSMX"]
TOKEN = "Oppaiboingboing123"
